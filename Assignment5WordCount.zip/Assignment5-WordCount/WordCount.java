
/**
 * Write a description of class WordCount here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class WordCount
{
    public static void main(String[] args) throws FileNotFoundException {
        HashMap<String, Integer> wordMap= new HashMap<String, Integer>();
        
        File wordFile = new File("properkvj_1.txt");
        Scanner scan = new Scanner(new File("properkjv_1.txt"));
        while (scan.hasNext()) {
            String word = scan.next();
            if (wordMap.containsKey(word)) {
                int count = wordMap.get(word) + 1;
                wordMap.put(word, count);
            }
            else {
                wordMap.put(word, 1);
            }
        }
        scan.close();
        
        //Collections.sort(wordMap);
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        long millis = date.getTime();
        PrintWriter w = new PrintWriter("properkjv_1" + date.getTime() + ".txt");
        for (Map.Entry<String, Integer> entry : wordMap.entrySet ()) {
            System.out.println(entry);
            w.println(entry);
        }
        w.close();
    }

}

