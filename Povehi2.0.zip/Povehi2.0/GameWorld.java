import java.util.HashMap;
/**
 * Write a description of class GameWorld here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameWorld
{
    private static GameWorld instance;
    private Room entrance;
    private HashMap<Room, WorldMod> worldMods;
    
    
    /**
     * Constructor for objects of class GameWorld
     */
    private GameWorld()
    {
        worldMods = new HashMap <Room, WorldMod>();
        createWorld();
        NotificationCenter.getInstance().addObserver("PlayerEnteredRoom", this, "playerEnteredRoom");
    }
    
    public Room getEntrance()
    {
        return entrance;
    }
    
    public static GameWorld getInstance()
    {
        if(instance == null)
        {
            instance = new GameWorld();
        }
        return instance;
    }
    
    public void playerEnteredRoom(Notification notification)
    {
        Player player = (Player)notification.getObject();
        Room room = player.getCurrentRoom();
        System.out.println("<>");
        WorldMod theMod = worldMods.get(room);
        if(theMod != null)
        {
            theMod.process();
            System.out.println("\b\n<<<< Entering this module has unlocked another part of the ship >>>>\n");
            //NotificationCenter.getInstance().removeObserver("PlayerEnteredRoom", this, "playerEnteredRoom");
        }
    }
    
    private void createWorld()
    {
        Room crewQuarters = new Room("in the Crew Quarters. It is cold, ice cold in fact");
        Room kitchen = new Room("in the kitchen. Something smells rotten...");
        Room hallwayNorth = new Room("in the North Hallway");
        Room crewLounge = new Room("in the Crew Lounge. It is surprisingly empty for this time of night. You heard a click in the room behind you");
        Room lifeSupport = new Room("in Life Support Containment. There are signs of tampering everywhere");
        Room bridge = new Room("in the bridge of the ship. Screens glisten and static fills the air");
        Room southHallway = new Room("in the South Hallway");
        Room corridor = new Room("in Crew Corridor, this connects the Habitat Module to the rest of the ship");
        Room armory = new Room("in the Armory. All of the small arms have been taken from their holdings.");
        
        Room stratComm = new Room("in Strategic Command. Looks like every one left in a hurry");
        Room captainsQuarters = new Room("in the Captain's Quarters. There is someone crumpled on the north wall...");
        Room navigation = new Room("in the Navigation module. The ships connections to the outside world have been completely severed");
        Room lifeBoats = new Room("free at last... you make your way to the life boat and leave the ship to its grim demise.");

        Door door = Door.makeDoor(crewLounge, crewQuarters, "south", "north");
        door = Door.makeDoor(crewLounge, corridor, "west", "east");
        door = Door.makeDoor(corridor, hallwayNorth, "north", "south");
        door = Door.makeDoor(hallwayNorth, kitchen, "north", "south");
        door = Door.makeDoor(kitchen, southHallway, "north", "south");
        door = Door.makeDoor(southHallway, bridge, "north", "south");
        door = Door.makeDoor(bridge, armory, "east", "west");
        
        Terminal terminal1 = new Terminal(1, lifeSupport);
        lifeSupport.setTerminal(terminal1);
        
        Terminal terminal2 = new Terminal(2, captainsQuarters);
        captainsQuarters.setTerminal(terminal2);
        
        NPC jeff = new NPC("Jeff", corridor);
        corridor.setNPC(jeff);
        NPC tom = new NPC("Tom", bridge);
        bridge.setNPC(tom);
        
        Item flashlight = new Item("flashlight", 1, 1, 1, 1);
        crewQuarters.addItems("flashlight", flashlight);
        
        Item key = new Item("key", 1, 1, 1, 1);
        stratComm.addItems("key", key);
        
        
        
        door = Door.makeDoor(armory, stratComm,"north", "south"); 
        door = Door.makeDoor(stratComm, captainsQuarters, "north", "south");
        door = Door.makeDoor(navigation, lifeBoats, "south", "north");
        door.close();                            
        RegularLock aLock = new RegularLock();
        door.setDelegate(aLock);
        aLock.lock();
        aLock.removeKey();
        
        
        
        /*****************************************************/
        
        DarkRoom darkRoom = new DarkRoom();
        hallwayNorth.setDelegate(darkRoom);

        entrance = crewQuarters;
        WorldMod aMod = new WorldMod(crewLounge, crewQuarters, lifeSupport, "west", "east");
        worldMods.put(aMod.getTrigger(), aMod);
        aMod = new WorldMod(captainsQuarters, bridge, navigation, "west", "east");
        worldMods.put(aMod.getTrigger(), aMod);
    }
    
    private class WorldMod
    {
        Room trigger;
        Room worldsEnd;
        Room otherWorld;
        String worldsEndDirection;
        String otherWorldDirection;
        
        WorldMod(Room trigger, Room worldsEnd, Room otherWorld, String worldsEndDirection, String otherWorldDirection)
        {
            this.trigger = trigger;
            this.worldsEnd = worldsEnd;
            this.otherWorld = otherWorld;
            this.worldsEndDirection = worldsEndDirection;
            this.otherWorldDirection = otherWorldDirection;
        }
        
        void process()
        {
            Door door = Door.makeDoor(otherWorld, worldsEnd, otherWorldDirection, worldsEndDirection);
        }
        
        Room getTrigger()
        {
            return trigger;
        }
    }
}
