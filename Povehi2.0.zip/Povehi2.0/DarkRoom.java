import java.util.HashMap;
/**
 * Write a description of class DarkRoom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DarkRoom implements RoomDelegate
{
    private HashMap<String, Door> exits;
    private Door room;
    /**
     * Constructor for objects of class DarkRoom
     */
    public DarkRoom()
    {
        
    }
    
    public void setExit(String direction, Door door)
    {
        exits.put(direction, door);
    }
    
    public String getShortDescription()
    {
        return "";
    }
    
    public String getLongDescription()
    {
        return "this room is dark";
    }
    
    public String getExitString()
    {
        return "";
    }
    
    public Door getExit(String direction)
    {
        return exits.get(direction);
    }
    
    public void setExits(HashMap<String, Door> exits)
    {
        this.exits = exits;
    }
    
    public void setRoom(Room room)
    {
        
    }
}
