import java.util.*;

/**
 * Implementation of the 'go' user command.
 * 
 * @author Michael Kolling modified by Rodrigo A. Obando (2018)
 * Game idea and modifications done by James A. Cox (2019)
 * @version 1.0 (December 2002)
 */
public class GoCommand extends Command
{
    private ArrayList<String> goCommands = new ArrayList<String>();
    
    /**
     * Constructor for objects of class GoCommand
     */
    public GoCommand()
    {
        super("go");
    }

    public boolean execute(Player player)
    {
        if(hasSecondWord()) {
            String direction = getSecondWord();
            player.walk(direction);
        }
        else  {
            System.out.println("Go where?");
        }
        return false;
    }
    
}
