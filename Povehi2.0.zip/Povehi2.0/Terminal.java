
/**
 * Write a description of class Terminal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Terminal
{
    private int scienceReq;
    private Room containingRoom;
    
    /**
     * Constructor for objects of class Terminal
     */
    public Terminal()
    {
        scienceReq = 1;
        containingRoom = null;
    }
    
    public Terminal(int scienceReq, Room containingRoom){
        this.scienceReq = scienceReq;
        this.containingRoom = containingRoom;
    }
    
    public Room getContainingRoom(){
        return containingRoom;
    }
    
    public int getScienceReq(){
        return scienceReq;
    }
    
}
