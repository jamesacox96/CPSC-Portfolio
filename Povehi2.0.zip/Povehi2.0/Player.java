import java.util.*;

/**
 * This class represents players in the game. Each player has 
 * a current location.
 * 
 * @author Michael Kolling modified by Rodrigo A. Obando (2018)
 * Game idea and modifications done by James A. Cox (2019)
 * @version 1.0 (December 2002)
 */
public class Player
{
    private Room currentRoom;
    private HashMap<String, Item> heldItems;
    private List<String> goCommands;
    private int scienceLevel;

    /**
     * Constructor for objects of class Player
     */
    public Player(Room startingRoom)
    {
        currentRoom = startingRoom;
        goCommands = new ArrayList<String>();
        scienceLevel = 1;
        heldItems = new HashMap<String, Item>();
    }

    /**
     * Return the current room for this player.
     */
    public Room getCurrentRoom()
    {
        return currentRoom;
    }

    /**
     * Set the current room for this player.
     */
    public void setCurrentRoom(Room room)
    {
        currentRoom = room;
    }

    public List<String> getGoCommands(){
        return goCommands;
    }

    public void editGoCommands(){
        if(goCommands.size() > 1){   
            goCommands.remove((goCommands.size()) -1);
        }
        else{
            goCommands = null;
        }
    }

    /**
     * Try to walk in a given direction. If there is a door
     * this will change the player's location.
     */
    public void walk(String direction)
    {
        Door door = currentRoom.getExit(direction);
        if(goCommands == null){
            goCommands = new ArrayList<String>();
            goCommands.add(direction);
        }
        else{
            goCommands.add(direction);        
        }

        if (door == null)
            System.out.println("There is no door on " + direction);
        else {
            if(door.isOpen())
            {
                Room nextRoom = door.getRoomFromTheOtherSideOf(getCurrentRoom());
                setCurrentRoom(nextRoom);
                NotificationCenter.getInstance().postNotification(new Notification("PlayerEnteredRoom", this));
                System.out.println(nextRoom.getLongDescription());
            }
            else
            {
                System.out.println("the door on " + direction + " is locked.");
            }
        }
    }

    public void open(String direction)
    {
        Door door = currentRoom.getExit(direction);

        if (door == null)
        {
            System.out.println("there is no door on " + direction);
        }
        else
        {
            ActionResult result = door.open();
            switch(result)
            {
                case UNCHANGED_DONE:
                System.out.println("the door on " + direction + " is was already open.");
                break;
                case CHANGED_DONE:
                System.out.println("the door on " + direction + " is now open.");
                break;
                case UNCHANGED_NOT_DONE:
                System.out.println("the door on " + direction + " is still closed.");
                break;
            }
        }
    }

    public void unLock(String direction)
    {
        Door door = currentRoom.getExit(direction);
        Item key = heldItems.remove("key");       
        if(key != null){
            if (door == null)
            {
                System.out.println("there is no door on " + direction);
            }
            else
            {
                LockDelegate theLock = door.getDelegte();
                theLock.insertKey(key);
                ActionResult result = theLock.unlock();
                switch(result)
                {
                    case UNCHANGED_DONE:
                    System.out.println("the door on " + direction + " was already unlocked.");
                    break;
                    case CHANGED_DONE:
                    System.out.println("the door on " + direction + " is now unlocked.");
                    break;
                    case UNCHANGED_NOT_DONE:
                    System.out.println("the door on " + direction + " is still locked.");
                    break;
                }
                if(door.isOpen())
                {
                    System.out.println("the door on " + direction + " is now open.");
                }
                else
                {
                    open(direction);
                }
            }
        }
        else{
                System.out.println("You do not have the key");
            }
        }
    

    public void increaseScienceLevel(){
        scienceLevel++;
    }

    public int getScienceLevel(){
        return scienceLevel;
    }

    public String getItemString(){
        String returnItems = "Items: ";
        for(String itemName : heldItems.keySet())
        {
            returnItems += " " + itemName;
        }
        return returnItems;
    }

    public void addHeldItems(String name, Item item){
        heldItems.put(name, item);
    }

    public Item removeItem(String name){
        return heldItems.remove(name);
    }

    public void search(){
        if(!currentRoom.getRoomItems().isEmpty()){
            if(currentRoom.getShortDescription().equals("in the Crew Quarters. It is cold, ice cold in fact")){
                addHeldItems("flashlight",currentRoom.removeItem("flashlight"));
                System.out.println("You now have access to a flashlight");
                System.out.println("Simply type 'flashlight' to light dark areas");
            }
            else if(currentRoom.getShortDescription().equals("in Strategic Command. Looks like every one left in a hurry")){
                addHeldItems("key",currentRoom.removeItem("key"));
                System.out.println("You now have the key to the lifeboat module");
                System.out.println("Make your way east of the bridge after checking on the Captain");
                System.out.println("Once inside, type win to leave the ship for good");
            }

        }
        else{
            System.out.println("There are no items to find");
        }
    }

    public void talkToNPC(){
        if(currentRoom.getNPC() != null){
            if(currentRoom.getNPC().getName().equals("Jeff")){
                System.out.println("-Jeff, what the hell happened here?");
                System.out.println("-Captain went a little crazy he did, rest of us soon to follow... yes... yes...");
                System.out.println("-Where is the rest of the crew?");
                System.out.println("-Captain didnt tell us what he did with them... poor souls...");
                System.out.println(" However...");
                System.out.println(" Tom is still at the bridge... little worse off than me im afraid... yes... YES! HAHA");
                System.out.println("");
                System.out.println("It seems Jeff is on the brink of madness... we should probably move on...");
            }
            else if(currentRoom.getNPC().getName().equals("Tom")){
                System.out.println("Tom?");
                System.out.println("*Tom is muttering to himself, hunched over the ships gryo-senor,"); 
                System.out.println("seemingly lost in the lights put on by the holgram*");
                System.out.println("");
                System.out.println("You start to make out what he is saying...");
                System.out.println("-Povehi... darkness... unavoidable... doom");
                System.out.println("");
                System.out.println("It looks like he is not going to be much help");
            }
        }else{
            System.out.println("There is no one to talk to...");
        }
    }

    public void inspectRoom(){
        if(currentRoom.getTerminal() != null){
            System.out.println("There is a terminal in this room you can hack");
        }
        else if(currentRoom.getNPC() != null){
            System.out.println("There is someone in this room you can talk to");
        }
        else if(!currentRoom.getRoomItems().isEmpty()){
            System.out.println("There are some items to find here... try searching...");
        }
        else{
            System.out.println("There is nothing to find in this room, time would be better spent searching other areas of the ship");
        }
    }

    public void hackTerminal(){
        if(currentRoom.getTerminal() != null){
            if(currentRoom.getTerminal().getScienceReq() <= scienceLevel){
                if(scienceLevel == 1){
                    System.out.println("Data Log November 2, 2334");
                    System.out.println("Begin oxygen supply purge");
                    System.out.println("Initiate temperature equilibrium");
                    System.out.println("Cannot retrieve confirmation from mission control - access denied");
                    System.out.println("Overriden");
                    increaseScienceLevel();
                }
                else if(scienceLevel > 1){
                    System.out.println("Why cant the rest of the crew understand?");
                    System.out.println("The sheer beauty of it... the endless void...");
                    System.out.println("I must show them");
                    System.out.println("");
                    System.out.println("Further inspection of the terminal reveals that shortly before you woke up, the air locks were opened");
                }
            }
            else{
                System.out.println("You do not meet the science requirement for this terminal, please explore more of the ship");
            }
        }
        else{
            System.out.println("There is no terminal in this room");
        }
    }

    public String getEquipmentString(){
        return "";
    }

    public void useFlashlight()
    {
        getCurrentRoom().setDelegate(null);
        System.out.println("room is lit");
        System.out.println(currentRoom.getLongDescription());
    }

}
