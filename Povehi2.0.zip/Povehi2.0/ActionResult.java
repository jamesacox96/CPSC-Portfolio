
/**
 * Enumeration class ActionResult - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum ActionResult
{
    UNCHANGED_DONE, CHANGED_DONE, UNCHANGED_NOT_DONE
}
