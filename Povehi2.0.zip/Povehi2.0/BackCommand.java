import java.util.*;

/**
 * Write a description of class BackCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BackCommand extends Command
{
    
    /**
     * Constructor for objects of class GoCommand
     */
    public BackCommand()
    {
        super("back");
    }
    
    // /** 
     // * Try to go to one direction. If there is an exit, enter the new
     // * room, otherwise print an error message. Returns always 'false'.
     // */
    // public boolean execute(Player player)
    // {
        // if(hasSecondWord()) {
            // String direction = getSecondWord();
            // player.walk(direction);
            // goCommands.add((goCommands.size()), getSecondWord());
        // }
        // else {
            // // if there is no second word, we don't know where to go...
            // System.out.println("Go where?");
        // }
        // return false;
    // }
    public boolean execute(Player player){
        if(player.getGoCommands() != null){
            List<String> tempList = player.getGoCommands();
            String direction = tempList.remove((tempList.size()) -1);
            if(direction.equals("north")){
                direction = "south";
                player.walk(direction);
            }
            else if(direction.equals("south")){
                direction = "north";
                System.out.println(direction);
                player.walk(direction);
            }
            else if(direction.equals("east")){
                direction = "west";
                player.walk(direction);
            }
            else if(direction.equals("west")){
                direction = "east";
                player.walk(direction);
            }
            //player.walk(direction);
            player.editGoCommands();
        }
        else{
            System.out.println("Cannot go back... You are where you started");
        }
        return false;
    }
    
}
