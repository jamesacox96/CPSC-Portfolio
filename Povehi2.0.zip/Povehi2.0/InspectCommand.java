
/**
 * Write a description of class InspectCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class InspectCommand extends Command
{

    /**
     * Constructor for objects of class HackCommand
     */
    public InspectCommand()
    {
        super("inspect");
    }

    public boolean execute(Player player)
    {
        player.inspectRoom();
        return false;
    }
}
