
/**
 * Write a description of class UnLockCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class UnLockCommand extends Command
{
    private int x;

    /**
     * Constructor for objects of class UnLockCommand
     */
    public UnLockCommand()
    {
        super("unlock");
        
    }
    
    public boolean execute(Player player)
    {
        if(hasSecondWord())
        {
            String direction = getSecondWord();
            player.unLock(direction);
        }
        else
        {
            System.out.println("unlock what?");
        }
        return false;
    }
}
