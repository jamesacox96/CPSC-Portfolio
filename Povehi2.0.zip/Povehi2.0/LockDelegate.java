
/**
 * Write a description of interface LockDelegate here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface LockDelegate
{
    boolean isLocked();
    boolean isUnlocked();
    ActionResult lock();
    ActionResult unlock();
    boolean mayOpen();
    boolean mayClose();
    Item insertKey(Item key);
    Item removeKey();
}
