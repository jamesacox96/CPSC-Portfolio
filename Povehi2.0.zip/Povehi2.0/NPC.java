
/**
 * Write a description of class NPC here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NPC
{
    private Room containingRoom;
    private String name;
    
    public NPC(){
        name = "the Echo";
        containingRoom = null;
    }
    
    public NPC(String name,Room containingRoom){
        this.name = name;
        this.containingRoom = containingRoom;
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public Room getContainingRoom(){
        return containingRoom;
    }
    
    public void setContaingRoom(){
        this.containingRoom = containingRoom;
    }
    
    
    
}
