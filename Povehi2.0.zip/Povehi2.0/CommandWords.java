import java.util.HashMap;

/**
 * 
 * @author  Michael Kolling and David J. Barnes modified by Rodrigo A. Obando (2018).
 *          Game idea and modifications done by James A. Cox (2019)
 * @version 1.1 (December 2002)
 */

public class CommandWords
{
    private HashMap<String, Command> commands;

    /**
     * Constructor - initialise the command words.
     */
    public CommandWords()
    {
        commands = new HashMap<String, Command>();
        Command command = new GoCommand();
        commands.put(command.getName(), command);
        command = new HelpCommand(this);
        commands.put(command.getName(), command);
        command = new QuitCommand();
        commands.put(command.getName(), command);
        command = new FlashlightCommand();
        commands.put(command.getName(), command);
        command = new UnLockCommand();
        commands.put(command.getName(), command);
        command = new BackCommand();
        commands.put(command.getName(), command);
        command = new SearchCommand();
        commands.put(command.getName(), command);
        command = new HackCommand();
        commands.put(command.getName(), command);
        command = new TalkCommand();
        commands.put(command.getName(), command);
        command = new InspectCommand();
        commands.put(command.getName(), command);
        command = new WinCommand();
        commands.put(command.getName(), command);
    }

    /**
     * Given a command word, find and return the matching command object.
     * Return null if there is no command with this name.
     */
    public Command get(String word)
    {
        return commands.get(word);
    }

    public void showAll() 
    {
        for(String commandName : commands.keySet())
        {
            System.out.print(commandName + "  ");
        }
        System.out.println();
    }
}
