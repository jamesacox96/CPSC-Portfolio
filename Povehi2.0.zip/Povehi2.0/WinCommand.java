
/**
 * Write a description of class WinCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WinCommand extends Command
{
    private Room winCondition;
    
    public WinCommand()
    {
        super("win");
    }

    public boolean execute(Player player)
    {
        Room winCondition = new Room("free at last... you make your way to the life boat and leave the ship to its grim demise.");
        if(player.getCurrentRoom().getShortDescription().equals(winCondition.getShortDescription())){
            System.out.println("You enter the life boat, desperate to leave but unable to look away as the craft releases itself from the Accumulator");
            System.out.println("On the starboard side, you see it...");
            System.out.println("A black hole... as massive as at least 7 Sols...");
            System.out.println("Is this what the crew was talking about... Is this way they went insane?");
            System.out.println("");
            System.out.println("You are left to wonder what sort of horrors could lurk under the Event Horizon");
            System.out.println("as your life boat's cryosleep system gives off an eerie 'click' as it activates.");
            return true;
        }
        else{
            System.out.println("You have not made it off the ship yet");
            return false;
        }
    }
}
