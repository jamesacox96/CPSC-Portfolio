/**
 * Implementation of the 'quit' user command.
 * 
 * @author Michael Kolling modified by Rodrigo A. Obando (2018)
 * Game idea and modifications done by James A. Cox (2019)
 * @version 1.0 (December 2002)
 */
public class QuitCommand extends Command
{
    /**
     * Constructor for objects of class QuitCommand
     */
    public QuitCommand()
    {
        super("quit");
    }

    public boolean execute(Player player)
    {
        if(getSecondWord() == null) {
            return true;
        }
        else {
            System.out.println("I cannot quit that...");
            return false;
        }
    }

}
