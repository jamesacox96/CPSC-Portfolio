/**
 * This class is an abstract superclass for all command classes in the game.
 * Each user command is implemented by a specific command subclass.
 *
 * Objects of class Command can store an optional argument word (a second
 * word entered on the command line). If the command had only one word, 
 * then the second word is <null>.
 * 
 * @author  Michael Kolling and David J. Barnes modified by Rodrigo A. Obando (2018)
 * Game idea and modifications done by James A. Cox (2019)
 * @version 2.0 (December 2002)
 */

public abstract class Command
{
    private String secondWord;
    private String name;

    public Command(String name)
    {
        secondWord = null;
        this.name = name;
    }

    public String getSecondWord()
    {
        return secondWord;
    }

    public boolean hasSecondWord()
    {
        return secondWord != null;
    }

    public void setSecondWord(String secondWord)
    {
        this.secondWord = secondWord;
    }
    
    public String getName()
    {
        return name;
    }

    public abstract boolean execute(Player player);
}

