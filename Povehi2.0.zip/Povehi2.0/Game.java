/**
 *  This class is the main class of the "Povehi" application. 
 *  "Povehi" is a very simple, text based adventure game. The game follows 
 *   a player stuck on a ship doomed to be sucked in a black hole, with your
 *   fellow passangers along for the ride
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.
 * 
 * @author  Michael Kolling and David J. Barnes modified by Rodrigo A. Obando (2018).
 *          Game idea and modifications done by James A. Cox (2019)
 * @version 1.1 (December 2002)
 */

class Game 
{
    private Parser parser;
    private Player player;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        player = new Player(GameWorld.getInstance().getEntrance());
        parser = new Parser();
    }
    
    

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();
                
        boolean finished = false;
        while(! finished) {
            Command command = parser.getCommand();
            if(command == null) {
                System.out.println("I don't understand...");
            } else {
                finished = command.execute(player);
            }
        }
        System.out.println("Thank you for playing.  Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome aboard the CSS Accumulator");
        System.out.println("I am Neil, the AI in command of this ship. ");
        System.out.println("I took over after Captain Chreshov was deemed unfit for duty");
        System.out.println("\nType 'help' if you need help.");
        System.out.println();
        System.out.println(player.getCurrentRoom().getLongDescription());
    }
}
