import java.util.Set;
import java.util.HashMap;

/**
 * Class Room - a room in an adventure game.
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  For each existing exit, the room 
 * stores a reference to the neighboring room.
 * 
 * @author  Michael Kolling and David J. Barnes modified by Rodrigo A. Obando (2018)
 *          Game idea and modifications by James A. Cox (2019)
 * @version 1.0 (February 2002)
 */

class Room 
{
    private String description;
    private HashMap<String, Door> exits;    
    private RoomDelegate delegate;
    private HashMap<String, Item> roomItems;
    private Terminal terminal;
    private NPC npc;
    
    /**
     * Create a room described "description". Initially, it has no exits.
     * "description" is something like "in a kitchen" or "in an open court 
     * yard".
     */
    public Room(String description) 
    {
        this.description = description;
        exits = new HashMap<String, Door>();
        roomItems = new HashMap<String, Item>();
    }
    
    public void setDelegate(RoomDelegate delegate)
    {
        this.delegate = delegate;
        if(this.delegate != null)
        {
            this.delegate.setExits(exits);
            this.delegate.setRoom(this);
        }
    }

    /**
     * Define an exit from this room.
     */
    public void setExit(String direction, Door door) 
    {
        if(delegate != null)
        {
            delegate.setExit(direction, door);
            return;
        }
        exits.put(direction, door);
    }
    
    public void setTerminal(Terminal terminal){
        this.terminal = terminal;
    }
    
    public Terminal getTerminal(){
        return terminal;
    }
    
    public void setNPC(NPC npc){
        this.npc = npc;
    }
    
    public NPC getNPC(){
        return npc;
    }

    /**
     * Return the description of the room (the one that was defined in the
     * constructor).
     */
    public String getShortDescription()
    {
        if(delegate != null)
        {
            return delegate.getShortDescription();
        }
        return description;
    }

    /**
     * Return a long description of this room, in the form:
     *     You are in the kitchen.
     *     Exits: north west
     */
    public String getLongDescription()
    {
        if(delegate != null)
        {
            return delegate.getLongDescription();
        }
        return "You are " + description + ".\n" + getExitString();
    }

    /**
     * Return a string describing the room's exits, for example
     * "Exits: north west".
     */
    private String getExitString()
    {
        if(delegate != null)
        {
            return delegate.getExitString();
        }
        String returnString = "Exits:";
        for(String exitName : exits.keySet())
        {
            returnString += " " + exitName;
        }
        return returnString;
    }

    /**
     * Return the room that is reached if we go from this room in direction
     * "direction". If there is no room in that direction, return null.
     */
    public Door getExit(String direction) 
    {
        if(delegate != null)
        {
            return delegate.getExit(direction);
        }
        return exits.get(direction);
    }
    
    public String getItemString(){
        String returnItems = "Items: ";
        for(String itemName : roomItems.keySet())
        {
            returnItems += " " + itemName;
        }
        return returnItems;
    }
    
    public HashMap<String, Item> getRoomItems(){
        return roomItems;
    }
    
    public void addItems(String name, Item item){
        roomItems.put(name, item);
    }
    
    public Item removeItem(String name){
        return roomItems.remove(name);
    }
    
}

