
/**
 * Write a description of class SearchCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SearchCommand extends Command
{

    /**
     * Constructor for objects of class HackCommand
     */
    public SearchCommand()
    {
        super("search");
    }

    public boolean execute(Player player)
    {
        player.search();
        return false;
    }
}
