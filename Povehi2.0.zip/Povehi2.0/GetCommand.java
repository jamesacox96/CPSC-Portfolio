/**
 * Implementation of the 'go' user command.
 * 
 * @author Michael Kolling modified by Rodrigo A. Obando (2018)
 * Game idea and modifications done by James A. Cox (2019)
 * @version 1.0 (December 2002)
 */
public class GetCommand extends Command
{
    /**
     * Constructor for objects of class GoCommand
     */
    public GetCommand()
    {
        super("get");
    }

    /** 
     * Try to go to one direction. If there is an exit, enter the new
     * room, otherwise print an error message. Returns always 'false'.
     */
    public boolean execute(Player player)
    {
        if(hasSecondWord()) {
            if(getSecondWord() == "items"){
                player.getItemString();
            }
            else if(getSecondWord() == "equipment"){
                player.getEquipmentString();
            }
        }
        else {
            System.out.println("Get What?");
        }
        return false;
    }
}
