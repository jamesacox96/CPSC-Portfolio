
/**
 * Write a description of class HackCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HackCommand extends Command
{

    public HackCommand()
    {
        super("hack");
    }
    
    public boolean execute(Player player)
    {
        player.hackTerminal();
        return false;
    }
}
