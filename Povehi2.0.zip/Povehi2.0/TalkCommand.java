
/**
 * Write a description of class TalkCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TalkCommand extends Command
{

    public TalkCommand()
    {
        super("talk");
    }

    public boolean execute(Player player)
    {
        player.talkToNPC();
        return false;
    }
}
