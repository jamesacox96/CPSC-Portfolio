
/**
 * Write a description of class ShazamCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FlashlightCommand extends Command
{
    public FlashlightCommand()
    {
        super("flashlight");
    }

    public boolean execute(Player player)
    {
        player.useFlashlight();
        return false;
    }
}
