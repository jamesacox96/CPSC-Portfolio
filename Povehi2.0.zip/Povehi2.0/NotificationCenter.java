import java.util.HashMap;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.lang.reflect.Method;

/**
 * The Notification Center is designed
 * after the NSNotificationCenter in
 * Cocoa (MacOS)
 *
 * @author (Rodrigo A. Obando)
 * @version (Fall 2018)
 */
public class NotificationCenter
{
    private HashMap<String, ArrayList<ObserverEntry>> observers; 
    private static NotificationCenter instance = null; 
    private Queue<NCCommand> commandQueue;

    private NotificationCenter()
    {
        observers = new HashMap<String, ArrayList<ObserverEntry>>();
        commandQueue = new LinkedList<NCCommand>();
    }

    public static NotificationCenter getInstance()
    {
        if(instance == null)
        {
            instance = new NotificationCenter();
        }
        return instance;
    }

    private class ObserverEntry
    {
        Object observer;
        String method;

        ObserverEntry (Object observer, String method)
        {
            this.observer = observer;
            this.method = method;
        }

        public boolean equals(Object other)
        {
            return this.observer.equals(((ObserverEntry)other).observer) && this.method.equals(((ObserverEntry)other).method);
        }
    }
    public void addObserver(String notificationName, Object observer, String methodName)
    {
        ArrayList<ObserverEntry> entryList = observers.get(notificationName);
        if(entryList == null)
        {
            entryList = new ArrayList<ObserverEntry>();
            observers.put(notificationName, entryList);
        }
        entryList.add(new ObserverEntry(observer, methodName));
    }

    public void queueAddObserver(String notificationName, Object observer, String methodName)
    {
        commandQueue.offer(new AddObserver(notificationName, observer, methodName));
    }

    /**
     * Removes an observer for a given notification name
     */
    public void removeObserver(String notificationName, Object observer, String methodName)
    {
        ArrayList<ObserverEntry> entryList = observers.get(notificationName);
        if(entryList != null)
        {
            boolean result = entryList.remove(new ObserverEntry(observer, methodName));
            if(entryList.size() == 0)
            {
                observers.remove(notificationName);
            }
        }

    }

    /**
     * queues an remove observer
     */
    public void queueRemoveObserver(String notificationName, Object observer, String methodName)
    {
        commandQueue.offer(new RemoveObserver(notificationName, observer, methodName));
    }

    public void ProcessQueue()
    {
        while(commandQueue.peek() != null)
        {
            NCCommand command = commandQueue.poll();
            command.execute();
        }
    }

    /**
     * Posts a notification to the NotificationCenter
     * It sends notifications to all observers/subscribers
     * to this notification
     */
    public void postNotification(Notification notification)
    {
        ArrayList<ObserverEntry> entryList = observers.get(notification.getName());
        if(entryList != null)
        {
            for(ObserverEntry observerEntry : entryList)
            {
                sendNotification(notification, observerEntry);
            }
        }
    }

    private void sendNotification(Notification notification, ObserverEntry observerEntry)
    {
        Class cls = observerEntry.observer.getClass();
        Method method = null;
        try
        {
            method = cls.getDeclaredMethod(observerEntry.method, Class.forName("Notification"));
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("sendNotification: " + e);
            return;
        }
        catch(NoSuchMethodException e)
        {
            System.out.println("sendNotification: " + e);
            return;
        }
        try
        {
            method.invoke(observerEntry.observer, notification);
        }
        catch(IllegalAccessException e)
        {
            System.out.println("sendNotification: " + e);
        }
        catch(java.lang.reflect.InvocationTargetException e)
        {
            System.out.println("sendNotification: " + e);
        }
    }

    private abstract class NCCommand
    {
        protected String notificationName;
        protected Object observer;
        protected String methodName;

        NCCommand(String notificationName, Object object, String methodName)
        {
            this.notificationName = notificationName;
            this.observer = observer;
            this.methodName = methodName;
        }

        abstract void execute();
    }

    private class AddObserver extends NCCommand
    {
        AddObserver(String notificationName, Object observer, String methodName)
        {
            super(notificationName, observer, methodName);
        }

        void execute()
        {
            addObserver(notificationName, observer, methodName);
        }
    }

    private class RemoveObserver extends NCCommand
    {
        RemoveObserver(String notificationName, Object observer, String methodName)
        {
            super(notificationName, observer, methodName);
        }

        void execute()
        {
            removeObserver(notificationName, observer, methodName);
        }
    }
}
