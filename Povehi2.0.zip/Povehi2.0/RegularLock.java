
/**
 * Write a description of class RegularLock here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RegularLock implements LockDelegate
{
    private boolean locked;
    private Item key;
    private Item insertedKey;
    /**
     * Constructor for objects of class RegularLock
     */
    public RegularLock()
    {
        locked = false;
        key = new Item("key", 1, 1, 1, 1);
        insertKey(key);
    }
    
    public boolean isLocked()
    {
        return locked;
    }
    
    public boolean isUnlocked()
    {
        return !locked;
    }
    
    public ActionResult lock()
    {
        if(isUnlocked())
        {
            if(insertedKey == key)
            {
                locked = true;
                return ActionResult.UNCHANGED_DONE;
            }
            else
            {
                return ActionResult.UNCHANGED_NOT_DONE;
            }
        }
        else
        {
            return ActionResult.UNCHANGED_DONE;
        }
    }
    
    public ActionResult unlock()
    {
        if(isLocked())
        {
            locked = false;
            return ActionResult.CHANGED_DONE;
        }
        else
        {
            return ActionResult.UNCHANGED_DONE;
        }
    }
    
    public boolean mayOpen()
    {
        if(isLocked())
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    public boolean mayClose()
    {
        if(isLocked())
        {
            return true;
        }
        else
        {
            return true;
        }
    }
    
    public Item insertKey(Item key)
    {
        insertedKey = key;
        return key;
    }
    
    public Item removeKey()
    {
        return insertKey(null);
    }
}
