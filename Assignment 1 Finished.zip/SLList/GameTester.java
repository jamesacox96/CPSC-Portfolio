
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import bridges.base.SLelement;
import bridges.connect.Bridges;
import java.util.Scanner;
import java.io.*;
import java.util.Random;
import java.lang.*;

public class GameTester
{
    public static int runGame(){
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        int numRoll;
        int newScore = 0;
        numRoll = rand.nextInt(100) + 1;
        System.out.println("This is a guessing game. Your score is based on how close you get to the random roll.");
        System.out.println("5-6 numbers off = 3 points.");
        System.out.println("3-4 numbers off = 4 points. ");
        System.out.println("2 numbers off = 5 points.");
        System.out.println("Correct Guess = 10 points.");
        int guess = Integer.parseInt(scan.nextLine());
        if (Math.abs(numRoll - guess) > 4 && Math.abs(numRoll - guess) < 7){
            newScore = newScore + 3;
        }
        else if (Math.abs(numRoll - guess) > 2 && Math.abs(numRoll - guess) < 5){
            newScore = newScore + 4;
        }
        else if (Math.abs(numRoll - guess) == 2){
            newScore = newScore + 5;
        }
        else if (Math.abs(numRoll -guess) == 1){
            newScore = newScore + 10;
        }
        System.out.println("Your guess: " + guess + "Num Roll: " + numRoll + "Points: " + newScore);
        return newScore;
    }
    public static void main(String[] args) throws Exception {
       HiScoresLL number_list = new HiScoresLL();
       GameEntry dd = new GameEntry("John", 0);
       number_list.addFirst(dd);
       GameEntry ee = new GameEntry("Bob", 4);
       number_list.add(ee);
       //number_list.display();
       //System.out.println(dd.getName());
       Bridges bridges = new Bridges(13, "cox_james4", "343699560018");
       //File HiScores = new File("HiScores.txt");
       //Scanner scan = new Scanner(HiScores);
       boolean flag = true;
       int newScore;
       String newName;
       try{
           File HiScores = new File("HiScores.txt");
           Scanner scoreScan = new Scanner(HiScores);
           while(scoreScan.hasNext()){
              String name = scoreScan.nextLine();
              int score = Integer.parseInt(scoreScan.nextLine());
              GameEntry HiScore = new GameEntry(name, score);
              number_list.add(HiScore);
              scoreScan.nextLine();
            }
        }catch (IOException e){
            System.out.println("File not found");
        }catch (NumberFormatException e){
            System.out.println("One of the lines in Hiscores.txt is invalid");
        }
       
       do{
           Scanner scan = new Scanner(System.in);
           System.out.println("What would you like to do?");
           System.out.println("1: Play a new game");
           System.out.println("2: See High Scores");
           System.out.println("3: Quit");
           int choice = Integer.parseInt(scan.nextLine()); 
           if(choice == 1){
               newScore = runGame();
               System.out.println("Please enter your name: ");
               newName = scan.nextLine();
               GameEntry newHiScore = new GameEntry(newName, newScore);
               number_list.add(newHiScore);
            }
            
           else if(choice == 2){
               number_list.display();
            }
            
           else if(choice == 3){
               flag = false;
            }
        }while(flag == true);                  
       
       number_list.writeData();
       
}
}