 public class DNode //<GameEntry> 
{

    protected Node head;
    protected int numNodes;
    protected Node tail;

    public DNode()
    {
        head = null; // head points to null
        numNodes=0;
        tail = null;
    }

    public void ListAppend(Node newNode) {
        if (head == null) { // List empty
            head = newNode;
            tail = newNode;
        }
        else {
            tail.next = newNode;
            newNode.prev= tail;
            tail = newNode;// tail= tail.next
        }
    }

    
    public void ListRemove(int i) {

        if(getSize()== 0){
            System.out.print("This data list is empty");
        }

        else{

            Node temp;
            temp = head;
            for( i = 1; i < i; i++)
                temp = temp.next;

            temp.prev.next= temp.next;
            temp.next.prev = temp.prev;

        }
  
        numNodes--;
    }

    public void addNode(Node e){
        Node temp;
        temp = head;
        
        if(e.data.getScore()> temp.data.getScore() && temp != null){
            temp = temp.next;
        }
        if(temp ==null){
            tail.next = e;
        }
        else if(temp == head){
            temp.prev = e;
            e.next = temp;
            head = head.prev;
        }
        else{
            temp.prev.next = e;
            temp.prev = e;

        }
        numNodes++;
    }

    public int getSize()    {
        return numNodes;
    }

    public void printList(int numNodes){
        Node curNode = head;
        while(curNode != null){
            System.out.println(curNode);
            curNode = curNode.next;
        }
    }

    protected class Node //<GameEntry>
    {
        //Declare class variables
        protected Node next;
        protected GameEntry data;
        protected Node prev;
        public Node(GameEntry data)
        {
            this.data = data;
            next = null;
            prev = null;
        }

        public Node(GameEntry data, Node next, Node prev) {
            this.data = data;
            this.next = next;
            this.prev = prev;
        }

    }
    
}