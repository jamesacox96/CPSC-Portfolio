
/**
 * Write a description of class HiScoresDLL here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HiScoresDLL extends DNode
{
    // instance variables - replace the example below with your own
    private Node head;
    private Node tail;
    private Node temp;
    private int numNodes;
    
    /**
     * Constructor for objects of class HiScoresDLL
     */
    public HiScoresDLL()
    {
        head = null;
        tail = null;
        
    }

   public void add(GameEntry e1){
       
     Node e = new Node (e1);
     super.addNode(e);
    }
    
    public void remove(int i){
     super.ListRemove(i);   
    }
}
