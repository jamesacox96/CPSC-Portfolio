import bridges.base.SLelement;
/**
 * Write a description of class HiScoresLL here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Scanner;
import java.io.*;

public class HiScoresLL extends SLList<GameEntry>
{
    // private SLelement<GameEntry> head;                  //head of list
    // private SLelement<GameEntry> tail;                  //tail of list
    // protected SLelement<GameEntry> curr;                //Access to current element
    // private int cnt;
    
    // /** 
       // * Constructor that creates an empty list 
       // */ 

     public HiScoresLL() {
        super();
     }
    
    /** 
       * Prints out all the game entries in the linked list 
       */ 

    public void display(){
        moveToStart();
            while(curr.getNext() != null){
            System.out.println(curr.getNext().getValue().toString());
            next();
        }
    }
    
    public void writeData()throws FileNotFoundException{
        moveToStart();
        PrintWriter w = new PrintWriter("HiScores.txt");
        while(curr.getNext() != null){
            GameEntry temp = curr.getNext().getValue();
            String varN = curr.getNext().getValue().getName();;
            int varS = curr.getNext().getValue().getScore();
            String lnbreak = ("=============");
            w.println(varN);
            w.println(varS);
            w.println(lnbreak);
            next();
            
        }
        w.close();
    }
    
    /** 
       * Add a node to the head of the list 
       * @param v 
       * the Node object to be added 

       */ 

    public void addFirst(GameEntry v){
        moveToStart();
        insert(v);
    }
    
    /** 
      * Removes the first node and returns it, 
      * this method assumes the list is non-empty 
      * @return 
      * the Node that was removed 

      */ 
      public GameEntry removeFirst(){ 
         moveToStart();
         GameEntry temp = remove();
         return temp;
         }

    /** 
       * Add a node to the tail of the list 
       * @param v 
       * the Node object to be added 

       */ 
    public void addLast(GameEntry v){
        moveToEnd();
        insert(v);
    }
    
    /** 
       * Assuming the list of game entries is in decreasing order by score, 
       * this method creates a Node with the given GameEntry e, and then 
       * inserts it in the appropriate spot in the list. 
       * @param e 
       * the GameEntry object to be added to the list 

       */

    public void add(GameEntry e){
        while(curr.getNext() != null){
            if(this.curr.getNext().getValue().getScore() <= e.getScore()){
                insert(e);
                break;
            }
            next();
        
        }
        
    }
    
    /** 
       * Removes the node at position i in the list 
       * (emulating an array index) 
       * @return 
       * the GameEntry of the removed node 
       * or null if position i is invalid 
       */ 

    public void remove(int i){
        if(length() == 0){
            System.out.println("The list is empty");
        }
        
        for(int j = 0; j < length(); j++){
            if (j == i){
                curr.setNext(curr.getNext().getNext());
            }
            curr = curr.getNext();
        }
    }
}
