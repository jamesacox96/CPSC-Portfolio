
/**
 * Write a description of class StringRecursion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Scanner;
import java.util.ArrayList;

public class StringRecursion
{
    public static void firstUpperCase(char[] stringList, int pos){
        char firstUpper;
        if(pos < stringList.length){
            char temp = stringList[pos];
            if(Character.isUpperCase(temp)){
                firstUpper = temp;
                System.out.println(temp);
            }
            pos++;
            firstUpperCase(stringList, pos);
        }
        else{
            return;
        }
        
    }
    
    public static int substrings(String subInput, int pos, int scope){
        if(scope == 1 && pos + scope >= subInput.length()){
            return 1;
        }
        
        if(pos + scope > subInput.length()){
            return substrings(subInput, 0, scope -1);
        }
        
        if(subInput.substring(pos, scope + pos).charAt(0) == 
                subInput.substring(pos, scope + pos).charAt(scope -1)){
                    return 1 + substrings(subInput, pos + 1, scope);
                    
                }
        
        return 0 + substrings(subInput, pos + 1, scope);        
        /*if(pos < subInput.length()){
            //System.out.println(subInput.substring(pos));
            //pos++;
            //substrings(subInput, pos);
            This is as far as I could get for this method 
            before the tutor lab*/
    }
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter a string with at least one uppercase letter.");
        String upperInput = scan.nextLine();
        char[] stringList = upperInput.toCharArray();
        firstUpperCase(stringList, 0);
        System.out.println("Please enter a string with at least two repeating characters.");
        String subInput = scan.nextLine();
        System.out.println(substrings(subInput, 0, (subInput.length() -1)));
        //String practice = "Hello";
        //System.out.println(practice.substring(0));
        //System.out.println(practice.substring(1));
        //System.out.println(practice.substring(2));
    }
}
