
/**
 * Write a description of class Token here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Token
{
    private Color color;
    /**
     * Constructor for objects of class Token
     */
    public Token()
    {
        this(Color.RED);
    }
    
    public Token(Color color)
    {
        this.color = color;
    }
    
    public String toString()
    {
        return color == Color.RED?"X":"O";
    }
}
