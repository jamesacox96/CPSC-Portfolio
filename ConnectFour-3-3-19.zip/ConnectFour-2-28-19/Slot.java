
/**
 * Write a description of class Slot here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Slot
{
    private Token token;
    /**
     * Constructor for objects of class Slot
     */
    public Slot()
    {
        token = null;
    }
    
    public String show()
    {
        return (token == null?"_":token.toString()) + "|";
    }
    
    public void setToken(Token token)
    {
        this.token = token;
    }
    
    public Token getToken()
    {
        return this.token;
    }
}
