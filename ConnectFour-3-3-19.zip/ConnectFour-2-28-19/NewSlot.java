
/**
 * Write a description of class NewSlot here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NewSlot
{
    private Token token;
    private NewSlot[] hood;
    /**
     * Constructor for objects of class NewSlot
     */
    public NewSlot()
    {
        hood = new NewSlot[8];
    }

    public void setToken(Token token)
    {
        this.token = token;
    }

    public Token getToken()
    {
        return this.token;
    }

    public void setConnection(NewSlot slot, Direction direction)
    {
        hood[direction.ordinal()] = slot;
    }

    public NewSlot getConnection(Direction direction)
    {
        return hood[direction.ordinal()];
    }

    public int numberOfNeighbors()
    {
        int counter = 0;
        for(int index = 0; index < hood.length; index++)
        {
            if(hood[index] != null)
            {
                counter++;
            }
        }
        return counter;
    }

    public String show()
    {
        // Enable the line below for normal operation
        //return (token == null?"_":token.toString());
        // Enable the line below for testing
        return (token == null?"" + numberOfNeighbors():token.toString());
    }

    public String print()
    {
        NewSlot east = getConnection(Direction.E);
        NewSlot south = getConnection(Direction.S);
        NewSlot west = getConnection(Direction.W);
        String temp = show() + "|" + (east == null?"":east.print());
        if(west == null && south != null)
        {
            temp += "\n" + south.print();
        }
        return temp;
    }

    public boolean drop(Token token)
    {
        if(getToken() != null) // I already have a token
        {
            return false;
        }
        else
        { // I don't have a token
            NewSlot south = getConnection(Direction.S);
            if(south == null) // There is nothing under me
            {
                setToken(token); // I keep the token
                return checkConnect(4);
            }
            else
            {
                if(south.getToken() == null)
                {
                    return south.drop(token); // drop the token down
                }
                else
                {
                    setToken(token);
                    return checkConnect(4);
                }
            }
        }
    }
    
    // You check whether you connected the number of tokens in a row, column or diagonals
    private boolean checkConnect(int number)
    {
        boolean fourInARow = false;
        if(number == 0){
            fourInARow = true;
            return fourInARow;
        }
        if(getConnection(Direction.N) != null){
            NewSlot north = getConnection(Direction.N);
            if(this.getToken() == north.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.NE) != null){
            NewSlot northEast = getConnection(Direction.NE);
            if(this.getToken() == northEast.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.E) != null){
            NewSlot east = getConnection(Direction.E);
            if(this.getToken() == east.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.SE) != null){
            NewSlot southEast = getConnection(Direction.SE);
            if(this.getToken() == southEast.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.S) != null){
            NewSlot south = getConnection(Direction.S);
            if(this.getToken() == south.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.SW) != null){
            NewSlot southWest = getConnection(Direction.SW);
            if(this.getToken() == southWest.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.W) != null){
            NewSlot west = getConnection(Direction.W);
            if(this.getToken() == west.getToken()){
                checkConnect(number - 1);
            }
        }
        if(getConnection(Direction.NW) != null){
            NewSlot northWest = getConnection(Direction.NW);
            if(this.getToken() == northWest.getToken()){
                checkConnect(number - 1);
            }
        }
        return fourInARow;
    }

    // This is still not working properly
    public void createGrid(int rows, int columns)
    {
        NewSlot east = getConnection(Direction.E);
        if(east == null)
        {
            east = new NewSlot();
        }
        NewSlot southEast = null;
        System.out.println("Rows: " + rows + " Columns: " + columns);
        if(columns > 1)
        {
            connectSlots(this, east, Direction.E, Direction.W);
            System.out.println(rows + " " + columns + " East-SouthEast");
            east.createGrid(rows, columns - 1);
            System.out.println(rows + " " + columns + " Return to East-SouthEast");
            southEast = east.getConnection(Direction.S);
            if(southEast == null)
            {
                System.out.println("Error!");
            }
            else
            {
                connectSlots(this, southEast, Direction.SE, Direction.NW);
            }
        }

        if(rows > 1)
        {

            NewSlot south = getConnection(Direction.S);
            if(south == null)
            {
                south = new NewSlot();
            }
            connectSlots(this, south, Direction.S, Direction.N);
            if(southEast != null)
            {
                connectSlots(south, southEast, Direction.E, Direction.W);
            }
            System.out.println(rows + " " + columns + " South");
            south.createGrid(rows - 1, columns);                
            System.out.println(rows + " " + columns + " Return to South");
            if(southEast != null)
            {
                connectSlots(east, south, Direction.SW, Direction.NE);
            }
        }
    }

    public static void connectSlots(NewSlot slot1, NewSlot slot2, Direction direction1, Direction direction2)
    {
        System.out.println("Slot1: " + slot1 + ", Slot2: " + slot2 + ", Direction1: " + direction1 + ", Direction2: " + direction2);
        slot1.setConnection(slot2, direction1);
        slot2.setConnection(slot1, direction2);
    }
}
