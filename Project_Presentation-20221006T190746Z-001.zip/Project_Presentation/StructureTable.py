# AUTHOR : Himanshu Bohra
# PreReq + Taken Table (Dictionary) [Contains the 'taken' tag/boolean]
# Gives structure to the DAG, output utilized by the DAG Generator
# It maybe better to have I1 and I2 processor send a whole string, less time
# complexity / processing power required. Else here, we do it each inputArray
# Nick-named : TLB (courtesy of John Morales)

class StructureTable:

    def __init__(self):
        self.Table = {}
        # In case this setdefault to have a key:array pair doesn't work<iter>
        #self.Table.setdefault(None, [])



    # Add the inputArray value into an array, so T/F bool can be added later.
    def AddPair(self, inputCourseID, inputPreReqArray):
        completedValue = [inputPreReqArray, False]
        self.Table[inputCourseID] = completedValue


    # Each record in the inputArray: ['nameID level',PreReqArray[]] /Default
    # This is the main function that does everything for the driver.
    def batchBuild(self, inputArray: [], inputNotTakenArray):
        for eachRecord in inputArray:
            #currentKeyString = eachRecord[0]
            self.AddPair(eachRecord[0], eachRecord[1])
        if inputNotTakenArray != None:
            self.SetTakenFlags(inputNotTakenArray)
        return self.Table
        


    # Boolean value flags. T = taken , (F = not taken). InpEmpty = none taken.
    # single Input entry = 'CPSC 1301' ; no need for 2D array.
    # So, during DAG generator, DG can reverse lookup keys from value==True
    # this will be faster to lookup in this Dict than in I1 parsed array.
    # Not using reverse look-up, at the expense of timeComplexity, gain modlrty.
    def SetTakenFlags(self, inputNotTakenArray):
        keys = self.Table.keys()
        for eachKey in keys:
            # currentKeyString = eachRecord[0] + ' ' + eachRecord[1]
            if eachKey not in inputNotTakenArray:
                truthValue = self.Table[eachKey]
                # print(str(truthValue)) # DEBUG CODE
                truthValue[1] = True
                self.Table[eachKey] = truthValue


    # ToString  TEMP RETURNING CLASS VAR FOR TESTING
    def ToString(self):
        return self.Table
