# Author: Himanshu Bohra

def xlModuleFormatWriter(inputAcademicYear):
    outputArray = inputAcademicYear.getSemesters()

    return outputArray
    
