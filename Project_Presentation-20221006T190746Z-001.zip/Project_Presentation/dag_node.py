class dag_node():
    def __init__(self, course, taken = False, hours = 3):
        #Course Class
        self.course = course
        self.taken = taken
        self.credit_hours = hours

    def is_taken(self):
        return self.taken

    def get_course_name(self):
        return self.course.getName()

    def to_string(self):
        return self.course.ToString()

    def set_taken(self, bool):
        self.taken = bool

    def set_to_taken(self):
        self.taken = True

    def set_not_taken(self):
        self.taken = False

    def get_course(self):
        return self.course

    def get_credit_hours(self):
        return self.credit_hours

    def set_credit_hours(self, hours):
        self.credit_hours = hours