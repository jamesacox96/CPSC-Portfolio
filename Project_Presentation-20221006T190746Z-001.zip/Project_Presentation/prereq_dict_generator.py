"""
Sample Input 2 output

[
['CPSC 1301',['MATH 1111']],
['CPSC 4444', ['ENGL 1122', 'ECON 1122']]
['CPSC 2108', [] ]
]
Taken Course List Sample
[
    'POLS 1101',
    'CPSC 3165',
    'CPSC 4000',
]
"""

def lookup_dict(prereq_list: list) -> dict:
    ret_dict = {}

    for course in prereq_list:
        #dictionary init with False for taken bool
        ret_dict[course[0]] = [course[1], False]

    return ret_dict

def apply_taken_courses(prereq_dict:dict, course_list:list) -> dict:
    keys = prereq_dict.keys()
    for key in keys:
        if key not in course_list:
            value = prereq_dict[key]
            value[1] = True
            prereq_dict[key] = value

    return prereq_dict