import pdf_parser
import prereq_parser
import schedule_parser
import not_taken_courses_formatter
import CourseGenerator
import StructureTable
import dag_generator
import Processor

import ExcelOutput

pdf_File = None
pdf_File = "Sample Input1.pdf"

prereq_file = "software engineering - track.txt"
schedule_file = "course schedules.txt"

#Init Module Objects
course_gen = CourseGenerator.CourseGenerator()
struct_table = StructureTable.StructureTable()
dagraph_gen = dag_generator.dac_graph()
processor = Processor.Processor()

parsed_pdf = None
course_gen_input, table = prereq_parser.prereq_parser(prereq_file)
season_input = schedule_parser.parse_file(schedule_file)


course_gen.batchBuild(course_gen_input)
course_gen.batchSchedule(season_input)
course_list = course_gen.getCourses()

lookup_table = struct_table.batchBuild(table, parsed_pdf)

graph = dagraph_gen.generate_dag(course_list, lookup_table)
dagraph_gen.draw_graph()

