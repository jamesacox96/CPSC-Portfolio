# AUTHOR : Himanshu Bohra
# The main logic to process the Directional Acyclic Graph. This module processes all nodes and puts them in correct semester objects.
# PROTOTYPE: the output for the ProcessDAG() function is a 2D array of strings, later on this will be changed to an AcademicYear object.
# Logic: Level based processing, takes each level of the graph and processes all the nodes, till there are no more nodes left in the graph.

import networkx as nx
from Semester import Semester
from AcademicYear import AcademicYear



class Processor:

    def __init__(self, inputDag = None):
        if inputDag is None:
            DAG = []            # Placeholder for the DAG map
        else: DAG = inputDag



    # If no dag provided, use what you have, otherwise set selfDag to thisDag
#-----------------------------MAIN DAG PROCESSING LOGIC----------------------

# LOGIC: get root, set it to level 0, get its children they are lvl1, once done
#        with children, extract all children of lvl1 in an array, they are lvl2.

    def ProcessDAG(self, inputDag = None):
        if inputDag is None:
            inputDag = self.DAG
        else: self.DAG = inputDag

        

        # function vars:
        loadConfigArray = self.loadConfigFile()
        seasonArray = loadConfigArray[0]
        startDate = loadConfigArray[1]
        seasonNameArray = loadConfigArray[2]

        # USE TOPOLOGICAL SORT TO GET ALL NODES AND ADD THEM ONE BY ONE.

        # rootNodes[0] = good, rootNodes[1] = bad
        unfilteredRootNodes = inputDag.root_nodes()
        goodRoots, badRoots = self.filterRoots(unfilteredRootNodes)
        # load up the current level array (lvl0) with the root nodes.
        levelArray = goodRoots

        # var init:
        #outputYearArray.append(AcademicYear(startDate[1]))
        outputYearArray = AcademicYear(startDate[1]) #[]
        outputYearArray.AddSemester(Semester(startDate[0]))

        # TEST:
        #outputYearArray, levelArray = self.processLevel(outputYearArray, levelArray, seasonArray)
        

        # GOOD ROOTS:
        while(levelArray):
            # print('TEST (outerloop)') ####### DEBUG
            # print('Season Array from config.ini : ' + str(seasonArray))
            outputYearArray, levelArray = self.processLevel(outputYearArray, levelArray, seasonArray)
            
        # BAD ROOTS (lone courses):
        levelArray = badRoots
        outputYearArray, levelArray = self.processLevel(outputYearArray, levelArray, seasonArray)


        # Process and sort the year (PROTOTYPE ONLY, later year needs to be selfsuff)------------------
        finalOutput = [] # just an array of strings
        processedSemesters = outputYearArray.getSemesters()
        freshYearDate = startDate[1]
        freshSeason = processedSemesters[0].getSchedule()

        concatString = freshSeason + ' ' + freshYearDate

        getScheduleNameString = ''

        #finalOutput.append(concatString)

        # SEMESTER BLOCK ARRAY, sent to the XLS module
        semesterBlockArray = []
        
        for eachSemester in processedSemesters:
            # First print out the date of the semester.
            #finalOutput.append(eachSemester.getSchedule() + ' ' + freshYearDate)
            scheduleNameString = self.getScheduleName(eachSemester.getSchedule(), seasonArray, seasonNameArray)
            semesterBlockArray.append([scheduleNameString + ' ' + freshYearDate])
            # If this is the last season, then we will +1 the year for the next time
            if eachSemester.getSchedule() == seasonArray[-1]:
                freshYearDate = int(freshYearDate) +  1
                freshYearDate = str(freshYearDate)

                        
            for eachCourse in eachSemester.getCourses():
                #finalOutput.append(eachCourse.getName())
                semesterBlockArray.append([eachCourse.getCompleteName(), str(eachCourse.getCreditHours())])

            # Finally, put the semester block (array) into the final output array:
            finalOutput.append(semesterBlockArray)
            # Empty out the semesterBlock for the next semester item
            semesterBlockArray = []

            
        
        return finalOutput #outputYearArray

        
        
#----------------------------------------------------------------------------


    # Check and separate good roots from bad roots(roots with 0 outDegrees):
    def filterRoots(self, unfilteredRoots):
        goodRoots = []
        badRoots = []
        returnedSeparatedRoots = []
        for eachUFRoot in unfilteredRoots:
            if self.DAG.node_out_degrees(eachUFRoot) > 0:
                goodRoots.append(eachUFRoot)
            else: badRoots.append(eachUFRoot)
        return goodRoots, badRoots


# ----------------------------- PROCESS A LEVEL of the DAG --------------
# Returns: the same main Year Array that is being worked on in the main ProcessDAG, with the
#          correctly added additional years and their respective semesters(+courses).
    def processLevel(self, inputCurrentYear, inputLevelArray, inputSeasonArray):

        # Get the current semester from the last year
        currentYear = inputCurrentYear #AcademicYear(currentYearDate)
        currentSemester = inputCurrentYear.getSemesters()[-1] #Semester(currentSeason)
        


        currentYearDate = currentYear.getDate()       #inputStartDate[1];
        currentSeason = currentSemester.getSchedule() #inputStartDate[0]

        # Init childArray
        childArray = []

        

        currentLevelArray = inputLevelArray
        
        # Put all the children of this node into childArray(the next lvl)
        for eachNode in currentLevelArray:
            childArray.extend(self.DAG.children_nodes(eachNode))

        # TEST
        #currentSeason = self.getNextScheduleValue(inputSeasonArray, currentSeason)
        #currentSemester = Semester(currentSeason)
        
        # run = True when there is any error/not all nodes in lvlArray processed
        run = True
        while(run):
            run = False
            for eachNode in currentLevelArray:
                if not eachNode.is_taken():
                    # AddCourse checks for season and isFull
                    if currentSemester.AddCourse(eachNode.get_course()):
                        eachNode.set_to_taken()
                    elif currentSemester.isFull():
                        # NOTE: For the PROTOTYPE we are just doing for an array for semesters for a Years class (doesnt hold actual years)
                        # If semester is full : Put it in the Years object (an array class for semesters)
                        #currentYearDate = inputCurrentYear[-1].getDate() + 1
                        # BEFORE ADDING IT AGAIN, CHECK IF ITS THE SAME SEMESTER (same season) : NO NEED , because it is being now done right b4LoopEnd
                        #inputCurrentYear.AddSemester(currentSemester)
                        currentSeason = self.getNextScheduleValue(inputSeasonArray, currentSeason)
                        currentSemester = Semester(currentSeason)
                        run = True
                    else: run = True
            if not run and not currentSemester.isFull():
                # peek into child array ; ensures the semester gets full
                for eachChild in childArray:
                    if not eachChild.is_taken():
                        # peek a child element, and check if parent in current semester
                        if not self.checkParentInSemester(self.DAG.parent_nodes(eachChild), currentSemester.getCourses()):
                            if currentSemester.AddCourse(eachChild.get_course()):
                                eachChild.set_to_taken()
                                if currentSemester.isFull():
                                    break#######

            # This AddSemester is so that we get done with the semester (because no more Season match are possible in this for each run)
            #inputCurrentYear.AddSemester(currentSemester)
            
            # ### DEBUG AREA -------------  ------------ DEBUG AREA ---------- DEBUG AREA --------- DEBUG AREA ---------- #########
            # print('Current Semester:' + currentSeason + ' ' + inputCurrentYear.getDate())  #### DEBUG #### ---------- STUCK IN WHILE LOOP
            # ## PRINT OUT THE LEVEL ARRAY
            # print('Current LEVEL ARRAY : ')
            # for eachNode in currentLevelArray:
            #     print(eachNode.get_course().getName() + ' ' + str(eachNode.get_course().getSchedule()))
            # print('Current CHILD ARRAY : ')
            # for eachNode in childArray:
            #     print(eachNode.get_course().getName())
            # print('Courses:------------- ')
            # for eachCourse in currentSemester.getCourses():
            #     print(eachCourse.getName())
            # print('---------------------')
            # # ------------- END OF DEBUG -----------------
            
            currentSeason = self.getNextScheduleValue(inputSeasonArray, currentSeason)
            currentSemester = Semester(currentSeason)

            # KEEP AN EYE ON THIS:
            inputCurrentYear.AddSemester(currentSemester)

        # ------- end of while loop------

        #currentSeason = self.getNextScheduleValue(inputSeasonArray, currentSeason)
        #currentSemester = Semester(currentSeason)
        #inputCurrentYear.AddSemester(currentSemester)
        

        # after prototype phase, dont return 2 variables, not modular (but reduces T.Complxty)
        return inputCurrentYear, childArray

#--------------------------------------------------------------------------------------------
        


    # Config File load function
    def loadConfigFile(self, customPath = "config.ini"):
        firstLine = ''
        secondLine = ''
        thirdLine = ''
        seasonArrayOut = []
        startDateArrayOut = []
        seasonNameArrayOut = []
        output = []
        with open(customPath, "r") as f:
            firstLine = f.readline().rstrip('\n')
            secondLine = f.readline().rstrip('\n')
            thirdLine = f.readline().rstrip('\n')

            seasonArrayOut = firstLine.split(",")
            startDateArrayOut = secondLine.split(',')
            seasonNameArrayOut = thirdLine.split(',')
            
            output.append(seasonArrayOut)
            output.append(startDateArrayOut)
            output.append(seasonNameArrayOut)
        
        return output#firstLine.split(",") , secondLine.split(',')


    def getNextScheduleValue(self, inputSeasonArray, currentSchedule):
        currentScheduleIndex = inputSeasonArray.index(currentSchedule)
        if currentScheduleIndex >= len(inputSeasonArray)-1:
            return inputSeasonArray[0]
        else:
            currentScheduleIndex += 1
            return inputSeasonArray[currentScheduleIndex]

    # CLONE/similar method OF THE ABOVE METHOD (dirty) || Returns 2 things, currentSeason and currentYearDate
    # DEPRECATED?
    def getNextDate(self, inputSeasonArray, currentSchedule, currentYearDate):
        currentScheduleIndex = inputSeasonArray.index(currentSchedule)
        if currentScheduleIndex >= len(inputSeasonArray)-1:
            currentYearDate += 1
            return inputSeasonArray[0], currentYearDate
        else:
            currentScheduleIndex += 1
            return inputSeasonArray[currentScheduleIndex], currentYearDate

    # Get the season code's full season name
    def getScheduleName(self, inputScheduleCode, inputScheduleCodeArray, inputScheduleNameArray):
        index = inputScheduleCodeArray.index(inputScheduleCode)
        return inputScheduleNameArray[index]

    def checkParentInSemester(self, parentNodeArray, semesterCourseArray):
        for eachNode in parentNodeArray:
            currentCourseName = eachNode.get_course_name()
            for eachSemesterCourse in semesterCourseArray:
                if eachSemesterCourse.getName() == currentCourseName:
                    return True
        return False
    
        
    
