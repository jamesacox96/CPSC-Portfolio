import pdf_parser
import prereq_parser
import schedule_parser
import not_taken_courses_formatter
import CourseGenerator
import StructureTable
import dag_generator
import Processor
import ExcelOutput

import ExcelOutput

def path_to_graduation(prereq_file, schedule_file, pdf_file = None):

    #Init Module Objects
    course_gen = CourseGenerator.CourseGenerator()
    struct_table = StructureTable.StructureTable()
    dagraph_gen = dag_generator.dac_graph()
    processor = Processor.Processor()

    #Phase 1 - Process 3 Inputs
    if pdf_file != None:
        input1 = pdf_parser.pdf_to_string(pdf_file)
        parsed_pdf = not_taken_courses_formatter.taken_courses_to_list(input1)
    else:
        parsed_pdf = None
    course_gen_input, table = prereq_parser.prereq_parser(prereq_file)
    season_input = schedule_parser.parse_file(schedule_file)


    course_gen.batchBuild(course_gen_input)
    course_gen.batchSchedule(season_input)
    course_list = course_gen.getCourses()

    lookup_table = struct_table.batchBuild(table, parsed_pdf)

    graph = dagraph_gen.generate_dag(course_list, lookup_table)

    if pdf_file != None:
        dagraph_gen.set_taken_in_graph_nodes(lookup_table)
    semester_list = processor.ProcessDAG(graph)
    return ExcelOutput.outputMain("outputTemplate.xlsx", semester_list)


if __name__ == "__main__":
    pdf_File = None
    # pdf_File = "Sample Input1.pdf"

    prereq_file = "software engineering - track.txt"
    schedule_file = "course schedules.txt"

    print(path_to_graduation(prereq_file, schedule_file, pdf_File))