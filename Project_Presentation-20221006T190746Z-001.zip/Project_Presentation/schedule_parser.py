# Author: Himanshu Bohra
# Input 3 module takes the season/schedule data and processes it into usable
# data. Separates Course ID, Course Level and array of season-schedule.

def parse_file(filePath = 'course schedules.txt'):
    i3ModuleOutput = []
    fileInput = []
    with open(filePath) as f:
        fileInput = f.readlines()
        
    separatedValues = []

    for eachRecord in fileInput:
        
        seasonArray = []
        separatedValues = eachRecord.rstrip('\n')
        separatedValues = separatedValues.split(',')

        nameId = separatedValues[0]
        levelNumber = separatedValues[1]
        
        for item in separatedValues[2:]:
            seasonArray.append(item)

        i3ModuleOutput.append([nameId, levelNumber, seasonArray])


    return i3ModuleOutput
    
