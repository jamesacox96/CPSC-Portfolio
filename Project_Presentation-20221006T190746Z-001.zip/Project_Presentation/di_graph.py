from networkx import DiGraph
from dag_node import dag_node

class di_graph(DiGraph):
    def root_nodes(self) -> list:
        node_list = []
        for node in self.in_degree:
            if node[1] == 0:
                node_list.append(node[0])
        return self.get_nodes(node_list)

    def node_in_degrees(self, node) -> int:
        node_name = self.node_string(node)
        return self.in_degree[node_name]

    def node_out_degrees(self, node) -> int:
        node_name = self.node_string(node)
        return self.out_degree[node_name]

    def children_of_parents(self, node_list) -> list:
        return_list = []
        for node in node_list:
            child_list = self.children_nodes(node)
            for child in child_list:
                return_list.append(child)

    def parent_nodes(self, node) -> list:
        node_name = self.node_string(node)
        node_list = self.predecessors(node_name)
        return self.get_nodes(node_list)
    def children_nodes(self, node) -> list:
        node_name = self.node_string(node)
        node_list = self.successors(node_name)
        return self.get_nodes(node_list)

    def node_string(self, node) -> str:
        if isinstance(node, dag_node):
            return node.get_course_name()
        return node

    def get_nodes(self, nodes_str_list) -> list:
        return_list = []
        for name in nodes_str_list:
            return_list.append(self.get_node(name))

        return return_list

    def get_node(self, node_name) -> dag_node:
        return self.nodes[node_name]['data']