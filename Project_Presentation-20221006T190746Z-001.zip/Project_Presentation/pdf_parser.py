from PyPDF2 import PdfReader
def pdf_to_string(file_name: str) -> str:
    reader = PdfReader(file_name)
    num_pages = len(reader.pages)

    return_text = ''

    for page_num in range(num_pages):
        return_text += reader.pages[page_num].extract_text() + "\n"

    return return_text

if __name__ == "__main__":
    pass