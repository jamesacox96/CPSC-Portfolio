def prereq_parser(filename):
    courseGenOut = []
    tableOut = []
    with open(filename) as f:
        for line in f:
            listCourse = line.strip().split('#')
            course_name = listCourse[0].split()
            course_name.append(listCourse[1])
            courseGenOut.append(course_name)
            list_len = len(listCourse)

            if list_len < 3:
                tableOut.append([listCourse[0], []])
            else:
                index = 2
                prereq = []
                while index < list_len:
                    prereq.append(listCourse[index])
                    index += 1
                tableOut.append([listCourse[0], prereq])

    return courseGenOut, tableOut