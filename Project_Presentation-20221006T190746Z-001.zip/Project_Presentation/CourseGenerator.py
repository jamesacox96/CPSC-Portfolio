# AUTHOR : Himanshu Bohra
# Should we have the class variable to be accessible without protection?
# or create a clone, then return that? (protecting the class variable)

# NEED LIST: { AddAttribute: <give nameID/level/name/seasonArray[]>
#              this way it is dynamic, can add not just seasonSched but any.}

#-------------------------------------------------------------------------------

from Lib import copy   ## make deepcopy, getCourses
from Course import Course

class CourseGenerator:
    # CLASS VAR
    courses = []

    # init method or constructor
    def __init__(self):
        self.courses = []
        


    # Add course Method | Input from I2, except schedule.
    def AddCourse(self,
                 nameID='Not Specified',
                 levelNumber='Not Specified',
                 fullname='Not Specified',
                 schedule: [] = ['Not specified']):
        course = Course(nameID, levelNumber, fullname, schedule)
        self.courses.append(course)


    # Get Course Objects (list/Array)  // return func's return var, not new.
    # When driver uses an internal var multiTimes, oldCopy = garbageCollected.
    # This is for future proofing and testing for now.
    def getCourses(self):
        # Will create a complete clone of all courses and their values[security] 
        return copy.deepcopy(self.courses)


    # Get a single course, non copy. For internal and external uses.
    def getCourse(self,inputnameID, inputLevel):
        for eachCourse in self.courses:
            if eachCourse.nameID == inputnameID and eachCourse.level == inputLevel:
                return eachCourse

        # Unsure if we should have an else to control return value. Default=None.
        else: return None  
            


    # Batch generate courses[] with a provided array(input/records) | I2 input.
    # each 'record' will be an array item, which is an array itself. 3d array.
    def batchBuild(self, inputArray: [] = ['Empty/Invalid Record']):
        for eachRecord in inputArray:
            self.AddCourse(eachRecord[0], eachRecord[1], eachRecord[2])

        
        return self.courses


    # Set Attribute(sechdule[]/season) Need to search it in I3[dict] not crslst
    # this will be called during when the driver sends roy's input
    # set through a func, not direct access to class var.
    def SetSchedule(self, courseObject: Course, scheduleSeason: []):
        courseObject.SetSchedule(scheduleSeason)


    # BatchBuild I3 ['CPSC 1301', <seasonArray>]
    def batchSchedule(self, inputI3Array: [] = ['Empty/Invalid Record']):
        for eachRecord in inputI3Array:
            self.SetSchedule(self.getCourse(eachRecord[0],eachRecord[1]),
                             eachRecord[2])
            
 
    # ToString Method
    def ToString(self):
        returnString = ''
        for eachCourse in self.courses:
            returnString += eachCourse.ToString() + '\n'
        return returnString
