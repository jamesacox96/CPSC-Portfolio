import os
import pathlib

from openpyxl import Workbook
from openpyxl import load_workbook
import pdb
from openpyxl.utils import get_column_letter
import sys

def generate_file_name(filename):
    dirs = os.listdir()
    filename_list = filename.split(".")

    file_index = 0
    if filename not in dirs:
        return filename
    else:
        while True:
            file_index += 1
            temp_file_name = filename_list[0] + str(file_index) + "." + filename_list[1]
            if temp_file_name not in dirs:
                return temp_file_name

def find_file_path(filename):
    return str(pathlib.Path().absolute()) + "\\" + filename

def loadWorkbook(filename):
        wb = load_workbook(filename)
        return wb

def activeWorksheet(wb):
        ws = wb.active
        return ws

def writeData(courseList, ws):
        #for item in courseList:
            #for double_deep_item in item:
                #ws.append(double_deep_item)
        #above dont work monke see monke do
        row = 3
        col = 1
        current_row = row
        for semester in courseList:
            for list in semester:
                for item in list:
                    if item == '3':  #this if statement keeps pushing data too far to right, need to reset y value
                        col = col + 1
                        current_row = current_row - 1
                        item = 3
                    ws.cell(row = current_row, column = col, value = item)
                    current_row = current_row + 1
                    if item == 3:
                        col = col - 1

            col = col + 2

            if col > 6:
                row = row + 9
                current_row = row
                col = 1
            else:
                current_row = row

        return ws

def saveData(wb, ws, courseList, output_filename):
        writeData(courseList, ws)
        wb.save(filename = output_filename)

def outputMain(filename, courseList, output_file_name = "Path to Graduation.xlsx"):
        new_file_name = generate_file_name(output_file_name)
        wb = loadWorkbook(filename)
        ws = activeWorksheet(wb)
        #writeData(courseList, ws)
        #ws = writeData(courseList, ws)
        saveData(wb, ws, courseList, new_file_name)
        return find_file_path(new_file_name)

# courseList = [
#  [
#  ["Fall 2022"],
#  ["Math 2125 - Intro to Discrete Math", "3"],
#   ["CPSC 3125 - Class", "3"],
#    ["Math 2125 - Intro to Discrete Math", "3"],
#  ],
#  [
#  ["Spring 2023"],
#  ["Math 2125 - Intro to Discrete Math", "3"],
#   ["Math 2125 - Intro to Discrete Math", "3"],
#   ["Math 2125 - Intro to Discrete Math", "3"],
#  ],
#  [
#    ["Summer 2023"],
#    ["Math 2125 - Intro to Discrete Math", "3"],
#      ["Math 2125 - Intro to Discrete Math", "3"],
#     ["Math 2125 - Intro to Discrete Math", "3"],
#    ],
# [
#  ["Fall 2023"],
#  ["Math 2125 - Intro to Discrete Math", "3"],
#   ["CPSC 3125 - Class", "3"],
#    ["Math 2125 - Intro to Discrete Math", "3"],
#  ]
# ]
#
# outputMain(courseList)



# pdb.run('ExcelCode.test()')

# wb = Workbook()
# dest_filename = "graduationPathTest.xlsx"
# ws1 = wb.active
# ws1.title = "Graduation Path"


# list_ultimate = [
# [
# ["Fall 2022"],
# ["Math 2125 - Intro to Discrete Math", "3"],
#  ["CPSC 3125 - Class", "3"],
#   ["Math 2125 - Intro to Discrete Math", "3"],
# ],
# [
# ["Spring 2023"],
# ["Math 2125 - Intro to Discrete Math", "3"],
#  ["Math 2125 - Intro to Discrete Math", "3"],
#  ["Math 2125 - Intro to Discrete Math", "3"],
# ],
# [
#   ["Summer 2023"],
#    ["Math 2125 - Intro to Discrete Math", "3"],
#     ["Math 2125 - Intro to Discrete Math", "3"],
#     ["Math 2125 - Intro to Discrete Math", "3"],
#   ]
# ]

# for item in list_ultimate:
# for double_deep_item in item:
# ws1.append(double_deep_item)

# wb.save(filename = dest_filename)
