# AUTHOR : Himanshu Bohra

class Course:
 
    # init method or constructor
    def __init__(self,
                 nameID='CPSC',
                 levelNumber='1300',
                 fullname='Not Specified',
                 schedule: [] = ['Not specified'],
                 creditCount = 3):
        self.nameID = nameID
        self.level = levelNumber
        self.name = fullname
        self.schedule = schedule
        self.creditHours = creditCount

    # Set attributes

    def SetSchedule(self, inputSchedule: []):
        self.schedule = inputSchedule


    # GETTERS

    def getName(self):
        return self.nameID + ' ' + self.level

    def getCompleteName(self):
        return self.nameID + ' ' + self.level + ' - ' + self.name

    def getSchedule(self):
        return self.schedule

    def getCreditHours(self):
        return self.creditHours
 
    # ToString Method
    def ToString(self):
        returnString = self.nameID
        returnString += ', '+self.level
        returnString += ', '+self.name
        returnString += ', '+ str(self.schedule)
        return returnString

