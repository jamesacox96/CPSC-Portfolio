# AUTHOR : Himanshu Bohra

class AcademicYear:

    def __init__(self, inputDate, inputMaxSemesters = 3):
        # The number of semesters/Year for Pr-loop should be in the config file.
        self.semesters = []
        self.maxSemesters = inputMaxSemesters
        self.date = inputDate


    def AddSemester(self, inputSemester):
        # if not self.isFull():
        self.semesters.append(inputSemester)
            # return True
        return False

    def isFull(self):
        if len(self.semesters) >= self.maxSemesters:
            return True
        return False
            


    def getSemesters(self):
        return self.semesters

    def getDate(self):
        return self.date
