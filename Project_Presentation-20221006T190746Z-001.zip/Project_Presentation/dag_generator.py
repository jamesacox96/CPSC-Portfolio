from di_graph import di_graph
import networkx as nx
from dag_node import dag_node

#mathplotlib required for draw_graph()

class dac_graph():

    def __init__(self):
        self.dag = di_graph()

    def generate_dag(self, courses_list, prereq_dict):
        self.create_nodes_in_graph(courses_list)
        self.link_nodes(prereq_dict)

        return self.dag

    def create_dag_node(self, course, is_taken = False):
        return dag_node(course, is_taken)

    def create_nodes_in_graph(self, course_list):
        for course in course_list:
            new_node = self.create_dag_node(course)
            course_name = new_node.get_course_name()
            #Nodes will use the course name as a unique ID ie: "CPSC 1301K"
            self.dag.add_node(course_name, data = new_node)

    def link_nodes(self, prereq_dict):
        course_keys = prereq_dict.keys()

        for course in course_keys:
            dict_value = prereq_dict.get(course)
            for prereq in dict_value[0]:
                self.dag.add_edge(prereq, course)

    def set_taken_in_graph_nodes(self, prereq_dict):
        list_of_nodes = self.dag.nodes()
        for node in list_of_nodes:
            val = prereq_dict.get(node)
            if val != None:
                taken_bool = val[1]
                current_node = self.dag.get_node(node)
                current_node.set_taken(taken_bool)

    def list_of_node_names(self):
        return self.dag.nodes()

    def draw_graph(self):
        import matplotlib.pyplot as plt

        #For visual debugging graph = generate_dag(courses)
        print(nx.is_directed_acyclic_graph(self.dag))  # returns True if it is a DAG
        plt.figure(figsize=(5, 5), dpi=100)

        nx.draw_planar(
            self.dag,
            arrowsize=20,
            with_labels=True,
            node_size=2000,
            node_color="#ffff8f",
            linewidths=2.0,
            width=1,
            font_size=8,
        )
        plt.show()