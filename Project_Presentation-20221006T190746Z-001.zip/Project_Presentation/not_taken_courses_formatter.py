def remove_junk_data(input: str) -> str:
    #Removes specified junk from the entire string
    return_input = input.replace('*', '')
    return_input = return_input.replace('AREA', '')
    return return_input

def taken_courses_to_list(raw_input: str)-> list[str]:
    course_list = []
    course_id = ""


    input = remove_junk_data(raw_input)
    split_lines = input.splitlines()

    for line in split_lines:
        found_course = False
        words = line.split()
        for word in words:
            #Assumes course names are 4 character long and uppercase
            if len(word) == 4 and word.isupper():
                course_id = word
                found_course = True
            #Assumes course number will never be longer than 5 characters and the first character is always a number
            elif found_course and len(word) <= 5 and word[0].isdigit():
                course_list.append(course_id + " " + word)

    return course_list
