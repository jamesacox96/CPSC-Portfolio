# AUTHOR : Himanshu Bohra
from Course import Course
class Semester:

    def __init__(self, inputSchedule = 'Fa', inputMaxCourses = 4):
        self.courses = []
        # Schedule is the season.
        self.schedule = inputSchedule
        self.maxCourses = inputMaxCourses


    def AddCourse(self, inputCourse):
        if not self.isFull() and self.compareSeasons(inputCourse):
            self.courses.append(inputCourse)
            return True
        else:
            return False

    def compareSeasons(self, inputCourse):
        courseSchedule = inputCourse.getSchedule()
        for eachSchedule in courseSchedule:
            if eachSchedule == self.schedule:
                return True
        return False

    def getCourses(self):
        return self.courses

    def getSchedule(self):
        return self.schedule

    def getMaxCourses(self):
        return self.maxCourses

    def getOpenSlotCount(self):
        openSlotCount = self.maxCourses - len(self.courses)
        return openSlotCount

    def isFull(self):
        if len(self.courses) >= self.maxCourses:
            return True
        else: return False

    


